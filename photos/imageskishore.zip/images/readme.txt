1.Nike Unisex Fury Headband 2.0 (3500)
Package Dimensions ‏ : ‎ 17.09 x 7.39 x 1.7 cm; 18 Grams
Date First Available ‏ : ‎ 3 December 2018
ASIN ‏ : ‎ B079Y7C1YT
Item part number ‏ : ‎ 00-9Y7C1YTE-IO
Country of Origin ‏ : ‎ USA

2.Puma unisex-adult Ferrari LS BB Cap(900)
Product details
Product Dimensions ‏ : ‎ 10 x 2 x 2.7 cm; 25 Grams
Date First Available ‏ : ‎ 17 March 2020
Manufacturer ‏ : ‎ PUMA SPORTS INDIA PVT LTD
ASIN ‏ : ‎ B0814X4H8G
Item model number ‏ : ‎ 022525
Country of Origin ‏ : ‎ Philippines

3.Fastrack Men Square Sunglasses(598)
Product details
Is Discontinued By Manufacturer ‏ : ‎ No
Product Dimensions ‏ : ‎ 14 x 4.1 x 4.1 cm; 20 Grams
Date First Available ‏ : ‎ 12 April 2017
Manufacturer ‏ : ‎ Fastrack
ASIN ‏ : ‎ B071CP6K43
Item model number ‏ : ‎ P357BK1
Country of Origin ‏ : ‎ China
Department ‏ : ‎ Men
Manufacturer ‏ : ‎ Fastrack


4. John Jacobs Polarized Sunglasses(1998)
Product Dimensions ‏ : ‎ 5.4 x 5.4 x 4.5 cm; 21 Grams
Date First Available ‏ : ‎ 10 November 2020
Manufacturer ‏ : ‎ Baofeng Framekart Technology Limited
ASIN ‏ : ‎ B08N4DBMTM
Item model number ‏ : ‎ JJ S12808
Country of Origin ‏ : ‎ China
Department ‏ : ‎ Unisex
Manufacturer ‏ : ‎ Baofeng Framekart Technology Limited


5.Fossil Minimalist Analog Black Dial Men's Watch-FS5848(13,495)
Product specifications
Watch Information
Band Colour	Black
Band Material	Stainless Steel
Band Width	22 Millimeters
Bezel Function	Unidirectional
Bezel Material	Stainless Steel
Brand	Fossil
Case Diameter	42 Millimeters
Case Material	Stainless Steel

6.Titan Metal Mechanicals Analog Green Dial Men's Watch-90140QM01(24,995)
Product specifications
Watch Information
Band Colour	Green
Band Material	Stainless Steel
Band Width	24.25 Millimeters
Bezel Function	No bezel available
Bezel Material	No bezel available
Brand	Titan
Calendar Type	No Calendar
Case Diameter	48.5 Millimeters
Case Material	Stainless Steel
Case Thickness	13 Millimeters
Clasp	Deployment Clasp
Collection	Titan Metal Mechanicals

7.Urban Forest Andrew Formal Reversible Belt(549)
Product details
Package Dimensions ‏ : ‎ 18.1 x 14.2 x 14 cm; 300 Grams
Date First Available ‏ : ‎ 16 July 2021
ASIN ‏ : ‎ B099N7RGT3
Item part number ‏ : ‎ UBF999REV8305
Country of Origin ‏ : ‎ India
Department ‏ : ‎ Men
Item Weight ‏ : ‎ 300 g


8.Bacca Bucci Men's Leather Belt(699)
Product details
Package Dimensions ‏ : ‎ 13.4 x 13.2 x 6.6 cm; 390 Grams
Date First Available ‏ : ‎ 1 January 2020
Manufacturer ‏ : ‎ Bacca bucci Fashions private limited
ASIN ‏ : ‎ B083F1PWPR
Item part number ‏ : ‎ BBBA1056A-36
Country of Origin ‏ : ‎ India
Department ‏ : ‎ Men

9.Saucony Men's Multi-pack Mesh Ventilating Comfort Fit Performance Crew Socks(3950)
Product details
Package Dimensions ‏ : ‎ 29.11 x 18.59 x 7.11 cm; 390 Grams
Date First Available ‏ : ‎ 26 June 2021
Manufacturer ‏ : ‎ Saucony
ASIN ‏ : ‎ B08KFP94TG
Item model number ‏ : ‎ S611002
Department ‏ : ‎ mens
Manufacturer ‏ : ‎ Saucony

10.Plain Soft Cotton Cloth Mask Washable & Reusable Cotton(259)
Product details
Product Dimensions ‏ : ‎ 12 x 12 x 10 cm; 150 Grams
Date First Available ‏ : ‎ 26 December 2021
Manufacturer ‏ : ‎ MEELANA MART GUJARAT
ASIN ‏ : ‎ B09P88N8V1
Item model number ‏ : ‎ New-6 Pcs Multi combo
Country of Origin ‏ : ‎ India
Department ‏ : ‎ unisex-adult
Manufacturer ‏ : ‎ MEELANA MART GUJARAT
Packer ‏ : ‎ meelana Mart
Item Weight ‏ : ‎ 150 g

11.Tommy Hilfiger Black Leather Men's Wallet( 1495)
Product details
Product Dimensions ‏ : ‎ 11.5 x 2 x 9.5 cm; 850 Grams
Date First Available ‏ : ‎ 3 October 2020
Manufacturer ‏ : ‎ Brand Concepts Ltd 140/2/2 Ring Road Musakhedi Square Indore Mp 452010
ASIN ‏ : ‎ B08KLXZPNW
Item model number ‏ : ‎ Eglinton
Country of Origin ‏ : ‎ India

12.Play2Fit 4 Wristband(399)
Product description
4 (Four) pieces of Cotton Wrist Bands , Size - 3 Inch or 5 inch.
 Color - As per selection. For Gym, Football, Cricket, Cycling, Exercise, Golf, 
and any sport where sweating is involved or Wrist support Required

13.UC5 Men's Leather Closed Fisherman Sandals(1299)
Product details
Product Dimensions ‏ : ‎ 33 x 20 x 12.5 cm
Date First Available ‏ : ‎ 1 August 2022
Manufacturer ‏ : ‎ Rathna Leathers Private Limited
ASIN ‏ : ‎ B0B8HLRK1P
Item model number ‏ : ‎ S41
Country of Origin ‏ : ‎ India

14.Hush Puppies mens Doughlas Sporty Sport Sandal(1599)
Product details
Product Dimensions ‏ : ‎ 33.3 x 20.5 x 12 cm; 1.64 Kilograms
Date First Available ‏ : ‎ 7 April 2022
Manufacturer ‏ : ‎ Expo Internation
ASIN ‏ : ‎ B09XDCQNJ2
Item model number ‏ : ‎ 8656001
Department ‏ : ‎ mens

15.MOQA Anti Slippery Sole leather Boots for Men Boots(1799)
Product details
Product Dimensions ‏ : ‎ 30 x 15 x 10 cm; 1.26 Kilograms
Date First Available ‏ : ‎ 26 August 2022
Manufacturer ‏ : ‎ RS MOQA
ASIN ‏ : ‎ B0BC1WHWJW
Item model number ‏ : ‎ boot-8
Country of Origin ‏ : ‎ India
Department ‏ : ‎ mens
Manufacturer ‏ : ‎ RS MOQA

16.Allen Cooper ACCS-824 High Ankle Genuine Premium Leather Boots for Men(1849)
Product details
Product Dimensions ‏ : ‎ 32 x 19 x 11 cm; 500 Grams
Date First Available ‏ : ‎ 14 May 2019
Manufacturer ‏ : ‎ J & M enterprises
ASIN ‏ : ‎ B07RT5X7JH
Item model number ‏ : ‎ accs-824
Country of Origin ‏ : ‎ India
Department ‏ : ‎ mens

17.Nike Mens Flex Experience Sports Shoes(4995)
Product details
Product Dimensions ‏ : ‎ 33 x 22 x 11 cm; 600 Grams
Date First Available ‏ : ‎ 20 July 2022
Manufacturer ‏ : ‎ NIKE INDIA PVT LTD
ASIN ‏ : ‎ B0B6G1CBWM
Item model number ‏ : ‎ DD9284-008
Department ‏ : ‎ mens

18.Adidas Men's Seize The Street M Running Shoes(3899)
Product details
Product Dimensions ‏ : ‎ 25 x 15 x 5 cm; 250 Grams
Date First Available ‏ : ‎ 6 December 2021
Manufacturer ‏ : ‎ ADIDAS INDIA MARKETING PRIVATE LIMITED
ASIN ‏ : ‎ B09N3M4JG4
Item model number ‏ : ‎ GB2440
Department ‏ : ‎ mens
Manufacturer ‏ : ‎ ADIDAS INDIA MARKETING PRIVATE 


19.Skechers Men's Flex Advantage 4.0-Providen Sneaker(3350)
Product details
Date First Available ‏ : ‎ 17 May 2022
Manufacturer ‏ : ‎ Skechers
ASIN ‏ : ‎ B0B1HWZTNV
Item model number ‏ : ‎ 232229-CCBK
Department ‏ : ‎ mens
Manufacturer ‏ : ‎ Skechers


20.US Polo Association Men's Abor Sneakers(1620)
Product details
Product Dimensions ‏ : ‎ 35 x 22 x 13 cm; 750 Grams
Date First Available ‏ : ‎ 4 February 2021
Manufacturer ‏ : ‎ Arvind Fashions Limited
ASIN ‏ : ‎ B08VWKCHXC
Item model number ‏ : ‎ 2FD21136N01
Department ‏ : ‎ mens
Manufacturer ‏ : ‎ Arvind Fashions Limited, Arvind Fashions Limited
Packer ‏ : ‎ Arvind Fashions Limited
Importer ‏ : ‎ Arvind Fashions Limited

21.BATA Men's Formal Dress Slip On Shoes(999)
Product details
Product Dimensions ‏ : ‎ 29 x 14 x 9 cm; 860 Grams
Date First Available ‏ : ‎ 16 September 2020
ASIN ‏ : ‎ B08J7J3XXD
Item model number ‏ : ‎ 851-4012-40
Department ‏ : ‎ mens
Item Weight ‏ : ‎ 860 g

22.Red Chief Leather Formal Shoe for Men's (1849)
Product details
Product Dimensions ‏ : ‎ 33 x 18 x 11 cm; 900 Grams
Date First Available ‏ : ‎ 13 September 2017
Manufacturer ‏ : ‎ Leayan Global Private Limited
ASIN ‏ : ‎ B075L9VWQ5
Item model number ‏ : ‎ RC3506 001
Department ‏ : ‎ mens
Manufacturer ‏ : ‎ Leayan Global Private Limited,


























